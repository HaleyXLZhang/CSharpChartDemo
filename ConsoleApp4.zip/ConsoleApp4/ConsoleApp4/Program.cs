﻿using ConsoleApp4.Model;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms.DataVisualization.Charting;
namespace ConsoleApp4
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                double maxYAxisMum=0, minYAxisMum=0;
                double minXAixsMum = 0;
                string alljson = File.ReadAllText("./Resources/SnR_InternalLatency.json");
                string coreuxprodbn2bJson = File.ReadAllText("./Resources/coreux-prod-bn2b.json");
                string coreuxprodch1bJson = File.ReadAllText("./Resources/coreux-prod-ch1b.json");
                string coreuxprodco4Json = File.ReadAllText("./Resources/coreux-prod-co4.json");
                Dictionary<string,string> dataCollect = new Dictionary<string, string>();
                dataCollect.Add("SnR_InternalLatency, Percentile95", alljson);
                dataCollect.Add("SnR_InternalLatency, coreux-prod-bn2b, Percentile95", coreuxprodbn2bJson);
                dataCollect.Add("SnR_InternalLatency, coreux-prod-ch1b, Percentile95", coreuxprodch1bJson);
                dataCollect.Add("SnR_InternalLatency, coreux-prod-co4, Percentile95", coreuxprodco4Json);
                List<SeriesInfo> pointsSet = new List<SeriesInfo>();
                List<DateTime> xvalsLists = new List<DateTime>();
                List<int> yvalsLists = new List<int>();
                foreach (KeyValuePair<string, string> data in dataCollect)
                {
                    var payload = JObject.Parse(data.Value)["QueryResults"];
                    // set up some data
                    List<DateTime> xvalsList = new List<DateTime>();
                    foreach (var item in payload)
                    {
                        xvalsList.Add(DateTime.Parse(item["LogDate"].ToString()));
                    }
                    xvalsLists.AddRange(xvalsList);
                     var xvals = xvalsList.ToArray();
                    List<int> yvalsList = new List<int>();
                    foreach (var item in payload)
                    {
                        yvalsList.Add(Convert.ToInt32(item["Percentile95"].ToString()));

                    }
                    yvalsLists.AddRange(yvalsList);
                    var yvals = yvalsList.ToArray();
                    pointsSet.Add(new SeriesInfo() { yAxis=yvals,xAxis=xvals, Name= data.Key });

                }
                minXAixsMum = xvalsLists.Min().ToOADate();
                maxYAxisMum = yvalsLists.Max();
                minYAxisMum = yvalsLists.Min();
                // create the chart
                var chart = new Chart();
                chart.Size = new Size(1900, 900);
                var chartArea = new ChartArea();
                chartArea.AxisX.LabelStyle.Format = "ddd d MMM\nhh:mm";
                chartArea.AxisX.MajorGrid.LineColor = Color.LightGray;
                chartArea.AxisY.MajorGrid.LineColor = Color.LightGray;
                chartArea.AxisX.LabelStyle.Font = new Font("Consolas", 8);
                chartArea.AxisY.LabelStyle.Font = new Font("Consolas", 8);
                chartArea.AxisY.Minimum = minYAxisMum;
                chartArea.AxisY.Maximum = maxYAxisMum;
                chartArea.AxisX.Minimum = minXAixsMum;
                chartArea.AxisY.Interval = 1;
                chartArea.AxisY.Title = "Value";
                chartArea.AxisX.Title = "Date";
                chartArea.AxisX.TitleFont= new Font("Consolas", 14);
                chartArea.AxisY.TitleFont = new Font("Consolas", 14);
                chart.ChartAreas.Add(chartArea);
                foreach (SeriesInfo seriesInfo in pointsSet)
                { 
                    Series series = new Series();
                    series.Name = seriesInfo.Name;
                    series.LegendText = seriesInfo.Name;
                    series.ChartType = SeriesChartType.Spline;
                    series.MarkerStyle = MarkerStyle.Circle;
                    series.XValueType = ChartValueType.DateTime;
                    if (series.Name.Equals("SnR_InternalLatency, Percentile95")) { series.Color = Color.LightSteelBlue; }
                    if (series.Name.Equals("SnR_InternalLatency, coreux-prod-bn2b, Percentile95")) { series.Color = Color.DarkOrange; }
                    if (series.Name.Equals("SnR_InternalLatency, coreux-prod-ch1b, Percentile95")) { series.Color = Color.SteelBlue; }
                    if (series.Name.Equals("SnR_InternalLatency, coreux-prod-co4, Percentile95")) { series.Color = Color.SandyBrown; }
                    chart.Series.Add(series);
                    // bind the datapoints
                    chart.Series[seriesInfo.Name].Points.DataBindXY(seriesInfo.xAxis, seriesInfo.yAxis);
                    Legend legend = new Legend();
                    legend.Name = series.Name;
                    legend.ForeColor = Color.Black;
                    legend.Docking = Docking.Top;
                    legend.Alignment = StringAlignment.Far;
                    chart.Legends.Add(legend);
                }   
                // draw!
                chart.Invalidate();
                // write out a file
                chart.SaveImage("chart.png", ChartImageFormat.Png);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.StackTrace);
            }
        }
    }
}
