﻿using System;

namespace ConsoleApp4.Model
{
    public class SeriesInfo
    {
        public string Name { get; set; }
        public DateTime[] xAxis { get; set; }

        public int[] yAxis { get; set; }
    }
}
